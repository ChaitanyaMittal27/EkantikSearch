from db_controller import debug_print

if __name__ == "__main__":
    print("\n✅ Current Questions in Ekantik_DB:\n")
    debug_print()
